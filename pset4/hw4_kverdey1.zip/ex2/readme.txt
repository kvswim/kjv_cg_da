The PDF is very hard to read and is only included for credit purposes (saved in portrait).
It is recommended to view the Excel xlsx spreadsheet instead. 